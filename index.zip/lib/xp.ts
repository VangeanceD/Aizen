export const XP_PER_LEVEL = 100
